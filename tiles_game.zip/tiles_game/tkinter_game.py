# Main Library to install and present to run this game_GUI

from tkinter import *
import time
from random import randint
from random import shuffle
from PIL import ImageTk,Image
from tkinter import messagebox

# Creating the root window to wor on them

game = Tk()
game.geometry("800x800+0+0")
game.title("Tiles game")

# frame which is created on game root window

frame = Frame(game,width=800,height=800,bg="maroon")
frame.place(x=0,y=0)

img = ImageTk.PhotoImage(Image.open("tile.jpg"))
label = Label(frame,image=img,width=800,height=800,bg="gray",fg="black")
label.place(x=0,y=0)

Message_m = StringVar()
text = Message(frame,textvariable=Message_m,relief=RAISED,bg="red",fg="black")
Message_m.set("Please enter row and column which sum is equal to size")
text.place(x=200,y=100)



Row = StringVar()
label2 = Label(frame,text="Row",width=20,height=3,bg="brown",fg="Black",bd=3)
label2.config(font=20)
label2.place(x=100,y=300)
entry1 = Entry(frame, textvariable=Row, width=20, bg="orange", fg="black", bd=5)
entry1.config(font=20)
entry1.place(x=550, y=300)

Column = StringVar()
label3 = Label(frame,text="Column",width=20,height=3,bg="brown",fg="Black",bd=3)
label3.config(font=20)
label3.place(x=100,y=400)
entry2 = Entry(frame, textvariable=Column, width=20, bg="orange", fg="black", bd=5)
entry2.config(font=20)
entry2.place(x=550, y=400)


buttom = Button(frame,text="Start",width=20,height=3,bd=3,bg='grey',fg='black',relief=SUNKEN,command = lambda:start(frame,entry1,entry2))
buttom.place(x=200,y=550)

buttom1 = Button(frame,text="Exit",width=20,height=3,bd=3,bg='grey',fg='black',relief=SUNKEN,command = lambda:exit(frame,game))
buttom1.place(x=500,y=550)

class Tile(object):
    def __init__(self, x, y, text, canvas):
        self.y = y
        self.x = x
        self.text = text
        self.canvas = canvas

    def Down(self):
        self.canvas.create_rectangle(self.x, self.y, self.x + 70, self.y + 70, fill="red")
        self.isFaceUp = False

    def Up(self):
        self.canvas.create_rectangle(self.x, self.y, self.x + 70, self.y + 70, fill="red")
        self.canvas.create_text(self.x + 35, self.y + 35, text=self.text, width=70)
        self.isFaceUp = True

    def Mouse(self, event):
        if (event.x > self.x and event.x < self.x + 70):
            if (event.y > self.y and event.y < self.y + 70):
                return True

OpenedTiles = []
chances = 0
tiles = []

def start(frame,entry1,entry2):
    global tiles
    size = int(entry1.get())+int(entry2.get())
    list = []
    if size<=9:
        for i in range(int(size)):
            list.append(i)
            canvas = Canvas(frame, width=800, height=800, bg="orange")
            canvas.place(x=0, y=0)


            open_tile = []
            for i in range(10):
                a = randint(0, len(list) - 1)
                num = list[a]
                open_tile.append(num)
                open_tile.append(num)
            shuffle(open_tile)
        NUM_COLS = int(entry2.get())
        NUM_ROWS = int(entry1.get())

        for x in range(0, NUM_COLS):
            for y in range(0, NUM_ROWS):
                tiles.append(Tile(x * 78 + 10, y * 78 + 40, open_tile.pop(), canvas))

        for i in range(len(tiles)):
            tiles[i].Down()

        game.bind("<Button-1>", mouseClicked)
    else:
        messagebox.askretrycancel("Error","Please Enter value in between 1 to 9 ")

def mouseClicked(event):
    global tiles
    global OpenedTiles
    global chances
    for tile in tiles:
        if tile.Mouse(event):
            if (not (tile.isFaceUp)):
                tile.Up()
                OpenedTiles.append(tile)
                chances += 1

            if (chances == 2):
                game.after(1000, checkTiles)
                chances = 0

def checkTiles():
    global OpenedTiles
    if not (OpenedTiles[-1].text == OpenedTiles[-2].text):
        OpenedTiles[-1].Down()
        OpenedTiles[-2].Down()
        del OpenedTiles[-2:]


def exit(fram,game):
    frame.quit()

game.mainloop()
